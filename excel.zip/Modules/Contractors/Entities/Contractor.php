<?php

namespace Modules\Contractors\Entities;

use Illuminate\Database\Eloquent\Model;

class Contractor extends Model
{
    public $table = 'contractors';
    
    protected $fillable = [];
}
