<?php

return [
    'name' => 'Settings'
];
