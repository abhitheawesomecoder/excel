<!DOCTYPE html>
<html>
<head>
    <title>Excel</title>
</head>
<body>
    <h3>{{ $message1 }}</h3>
    <p>{{ $link }}</p>

    <p>Thank you</p>
</body>
</html>
