<?php

namespace Modules\Contractorsignup\Entities;

use Illuminate\Database\Eloquent\Model;

class Contractorsignup extends Model
{
    public $table = 'contractorsignups';
    
    protected $fillable = [];
}
