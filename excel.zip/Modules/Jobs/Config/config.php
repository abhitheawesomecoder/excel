<?php

return [
    'name' => 'Jobs'
];
