<?php

namespace Modules\Jobs\Entities;

use Illuminate\Database\Eloquent\Model;

class Jobtype extends Model
{
    public $table = 'jobtypes';

    protected $fillable = [];
}
