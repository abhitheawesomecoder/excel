<?php

namespace Modules\Jobs\Entities;

use Illuminate\Database\Eloquent\Model;

class Signature extends Model
{

    public $table = 'signatures';

    protected $fillable = [];
}
