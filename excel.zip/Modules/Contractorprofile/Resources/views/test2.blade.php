<page_footer> 	
<table style="width: 100%;background-color: gray;border: 1px solid black;margin-bottom: 10px;">
	<tr><td style="text-align: right;" >Contractor Acceptance : </td><td>This work has been done as per customer requirement</td></tr>
	<tr>
	   <td style="text-align: right;">
	   	Signature :
	   </td>
       <td>
       	 <img style="height: 10%;" src="{{$sign->contractorcode}}" alt="Logo">
       </td>
    </tr>
    <tr><td style="text-align: right;">Date : </td><td>{{$sign->contractor_date}}</td></tr>
</table>
</page_footer>