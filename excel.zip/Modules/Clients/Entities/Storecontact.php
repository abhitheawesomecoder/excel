<?php

namespace Modules\Clients\Entities;

use Illuminate\Database\Eloquent\Model;

class Storecontact extends Model
{

    public $table = 'storecontacts';

    protected $fillable = [];
}
