<?php

namespace Modules\Clients\Entities;

use Illuminate\Database\Eloquent\Model;

class Store extends Model
{

    public $table = 'stores';

    protected $fillable = [];
}
