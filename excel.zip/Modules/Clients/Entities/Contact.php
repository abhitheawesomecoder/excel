<?php

namespace Modules\Clients\Entities;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{

    public $table = 'contacts';

    protected $fillable = [];
}
