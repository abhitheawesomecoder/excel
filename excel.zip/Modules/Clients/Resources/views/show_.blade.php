<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                        <div class="header-buttons">



                                                            <div class="btn-group next-prev-btn-group" role="group">

                                                                            <a href="http://62.75.143.29/vendors/vendors/24"
                                           title="Prev"
                                           class="btn btn-primary waves-effect btn-crud btn-prev">Prev</a>
                                    
                                                                            <a href="http://62.75.143.29/vendors/vendors/26"
                                           title="Next"
                                           class="btn btn-primary waves-effect btn-crud btn-next">Next</a>
                                                                    </div>
                            
                                <div class="btn-group btn-crud pull-right">
                                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        More <span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu">
                                                                                    <li>
                                                <a href="http://62.75.143.29/vendors/vendors/create?copy=25">Copy</a>
                                            </li>
                                        
                                    </ul>
                                </div>

                                                                    <form method="POST" action="http://62.75.143.29/vendors/vendors/25" accept-charset="UTF-8"><input name="_method" type="hidden" value="DELETE"><input name="_token" type="hidden" value="hBzjBrrKBa2WSm4VGChmnQqnAhr8YbxorSVxzn3x">

                                    <button type="submit" class="btn btn-danger waves-effect btn-edit btn-crud" onclick="return confirm($.i18n._(&#039;are_you_sure&#039;))">Delete</button>

                                    </form>
                                

                                <a href="http://62.75.143.29/vendors/vendors"
                               class="btn btn-primary waves-effect btn-back btn-crud">Back</a>

                                                            <a href="http://62.75.143.29/vendors/vendors/25/edit"
                                   class="btn btn-primary waves-effect btn-edit btn-crud">Edit</a>
                            


                        </div>


                        <div class="header-text">
                            Client - Details                            <small>Client include companies, people and contractors form which your company gets products and services.</small>
                        </div>
                    </h2> </div>
                    <div class="body">
                        <div class="row">
                            <div class="col-lg-2 col-md-2 col-sm-2">
                                <ul class="nav nav-tabs tab-nav-right tabs-left" role="tablist">
                                    <li role="presentation" class="active">
                                        <a href="#tab_details" data-toggle="tab" title="Details"> <i class="material-icons">folder</i> Details </a>
                                    </li>
                                    <li role="presentation">
                                        <a href="#tab_documents" data-toggle="tab" title="Store List"> <i class="material-icons">storage</i> Store List </a>
                                    </li>
                                    <li role="presentation">
                                        <a href="#tab_comments" data-toggle="tab" title="Comments"> <i class="material-icons">chat</i> Comments </a>
                                    </li>
                                    <li role="presentation">
                                        <a href="#tab_attachments" data-toggle="tab" title="Attachments"> <i class="material-icons">attach_file</i> Attachments </a>
                                    </li>
                                    <li role="presentation">
                                        <a href="#tab_updates" data-toggle="tab" title="Activity Log"> <i class="material-icons">change_history</i> Activity Log </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-lg-10 col-md-10 col-sm-10">
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane active" id="tab_details">
                                        <div class="col-lg-12 col-md-12"> </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <h2 class="card-inside-title">
        Basic information
        <div class="section-buttons">
                </div>
    </h2> </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Name </label> asdada </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Assigned To </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Category </label>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <h2 class="card-inside-title">
        Contact data
        <div class="section-buttons">
                </div>
    </h2> </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Phone </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Mobile </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Email </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Secondary email </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Fax </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Skype ID </label>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <h2 class="card-inside-title">
        Address information
        <div class="section-buttons">
                </div>
    </h2> </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Street </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> City </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> State </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Country </label>
                                        </div>
                                        <div class="field-wrapper col-lg-6 col-md-6 col-sm-6">
                                            <label class="show-control-label"> Zip code </label>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <h2 class="card-inside-title">
        Notes
        <div class="section-buttons">
                </div>
    </h2> </div>
                                        <div class="field-wrapper col-lg-12">
                                            <label class="show-control-label"> Notes </label>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 text-right entity-created-at">
                                            <div> Created On: <strong>2020-08-30 12:11</strong> by <strong>Panneylal Yadav</strong> </div>
                                            <div> Updated At: <strong>2020-08-30 12:11</strong> by <strong>Panneylal Yadav</strong> </div>
                                        </div>
                                    </div>
                                    <div role="tabpanel" class="tab-pane" id="tab_documents">
                                        <div class="related_module_wrapper">
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12">
                                                    <div class="select_relation_wrapper"> <a href="#" class="select btn btn-primary waves-effect modal-relation">Select</a>
                                                        <div id="modal_documents" class="modal fade" role="dialog">
                                                            <div class="modal-dialog modal-xl">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                        <h4 class="modal-title">Documents</h4> </div>
                                                                    <div class="modal-body linked-records">
                                                                        <div class="col-lg-12 col-md-12 col-sm-12 linked-records">
                                                                            <table class="table table-hover" id="VendorDocumentsDatatable_Select" width="100%">
                                                                                <thead>
                                                                                    <tr>
                                                                                        <th></th>
                                                                                        <th>Name</th>
                                                                                        <th>Created at</th>
                                                                                        <th>Updated at</th>
                                                                                        <th>Assigned to</th>
                                                                                    </tr>
                                                                                </thead>
                                                                            </table>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <form method="POST" action="http://62.75.143.29/vendors/vendors/documents-link" accept-charset="UTF-8" class="link-selected">
                                                                            <input name="_token" type="hidden" value="hBzjBrrKBa2WSm4VGChmnQqnAhr8YbxorSVxzn3x">
                                                                            <input name="entityId" type="hidden" value="25">
                                                                            <input name="relationEntityIds" type="hidden">
                                                                            <input name="modalName" type="hidden" value="modal_documents">
                                                                            <input name="linkedName" type="hidden" value="linked_documents">
                                                                            <button type="submit" class="btn btn-primary link-selected" title="Unlink relation" onclick="return confirm($.i18n._(&#039;are_you_sure&#039;))">Add selected</button>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="create_new_relation_wrapper"> <a href="#" class="select btn btn-primary waves-effect modal-new-relation">Create new</a>
                                                        <div data-create-route="http://62.75.143.29/documents/documents/create?relationType=manyToMany&amp;relatedField=vendors&amp;mode=modal&amp;relatedEntityId=25&amp;relatedEntity=Modules%5CVendors%5CEntities%5CVendor" id="modal_create_documents" class="modal fade" role="dialog">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                        <h4 class="modal-title">Create Document</h4> </div>
                                                                    <div class="modal-body"> </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 linked-records" id="linked_documents">
                                                    <table class="table table-hover" id="VendorDocumentsDatatable" width="100%">
                                                        <thead>
                                                            <tr>
                                                                <th></th>
                                                                <th>Name</th>
                                                                <th>Created at</th>
                                                                <th>Updated at</th>
                                                                <th>Assigned to</th>
                                                            </tr>
                                                        </thead>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="tabpanel" class="tab-pane" id="tab_comments">
                                        <div class="col-lg-12 col-md-12">
                                            <div id="entity-comments-container"> </div>
                                        </div>
                                    </div>
                                    <div role="tabpanel" class="tab-pane" id="tab_attachments">
                                        <div class="col-lg-12 col-md-12">
                                            <!-- The file upload form used as target for the file upload widget -->
                                            <form id="fileupload" action="http://62.75.143.29/core/extensions/attachments/upload-attachments" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="path" value="http://62.75.143.29/vendors/vendors/25" />
                                                <input type="hidden" name="entityId" value="25" />
                                                <input type="hidden" name="entityClass" value="Modules\Vendors\Entities\Vendor" />
                                                <!-- Redirect browsers with JavaScript disabled to the origin page -->
                                                <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
                                                <div class="row fileupload-buttonbar">
                                                    <div class="col-lg-12">
                                                        <p class="font-bold"> Allowed File Types: <span class="col-red">Jpg, Jpeg, Png, Pdf, Zip, Rar, Doc, Docx</span> </p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <!-- The fileinput-button span is used to style the file input field as button --><span class="btn btn-success fileinput-button">
                        <i class="glyphicon glyphicon-plus"></i>
                        <span>Add Files</span>
                                                        <input type="file" name="files" multiple> </span>
                                                        <button type="submit" class="btn btn-primary start"> <i class="glyphicon glyphicon-upload"></i> <span>Start Upload</span> </button>
                                                        <button type="reset" class="btn btn-warning cancel"> <i class="glyphicon glyphicon-ban-circle"></i> <span>Cancel Upload</span> </button>
                                                        <!-- The global file processing state --><span class="fileupload-process"></span> </div>
                                                    <!-- The global progress state -->
                                                    <div class="col-lg-6 fileupload-progress fade">
                                                        <!-- The global progress bar -->
                                                        <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                                            <div class="progress-bar progress-bar-success" style="width:0%;"></div>
                                                        </div>
                                                        <!-- The extended global progress state -->
                                                        <div class="progress-extended">&nbsp;</div>
                                                    </div>
                                                </div>
                                                <!-- The table listing the files available for upload/download -->
                                                <div class="table-responsive col-lg-12 col-md-12">
                                                    <table role="presentation" class="table table-striped">
                                                        <thead>
                                                            <th> Preview </th>
                                                            <th> Filename </th>
                                                            <th> Size </th>
                                                            <th> Options </th>
                                                        </thead>
                                                        <tbody class="files"></tbody>
                                                    </table>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div role="tabpanel" class="tab-pane" id="tab_updates">
                                        <div class="table-responsive col-lg-12 col-md-12">
                                            <table class="table table-hover" id="ActivityLogDatatable" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>Description</th>
                                                        <th>Updated by</th>
                                                        <th>Created at</th>
                                                    </tr>
                                                </thead>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>