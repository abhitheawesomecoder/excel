<?php

return [
    'name' => 'Signup'
];
