<!DOCTYPE html>
<html>
<head>
    <title>Excel</title>
</head>
<body>
    <h1>Click the link below to signup</h1>
    <p>{{ $link }}</p>

    <p>Thank you</p>
</body>
</html>
