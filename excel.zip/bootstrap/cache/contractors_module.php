<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Contractors\\Providers\\ContractorsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Contractors\\Providers\\ContractorsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);