<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Jobs\\Providers\\JobsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Jobs\\Providers\\JobsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);