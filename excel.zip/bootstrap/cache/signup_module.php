<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Signup\\Providers\\SignupServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Signup\\Providers\\SignupServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);